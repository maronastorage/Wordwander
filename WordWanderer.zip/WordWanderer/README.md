# WordWanderer 🌍
AI-powered vocabulary learning app for children ages 4-10.

## Setup
1. Replace YOUR_API_KEY_HERE in App.js line 14 with your Anthropic API key
2. Run: npm install
3. Build APK: eas build --profile preview --platform android

## Owner
Expo: wordexplore1
GitHub: maronastorage
