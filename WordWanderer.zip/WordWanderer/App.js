import { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView, TextInput,
  StyleSheet, Dimensions, Alert, Platform, ActivityIndicator,
  SafeAreaView, StatusBar, Image
} from 'react-native';
import { Camera, CameraType } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import * as Speech from 'expo-speech';

const W = Dimensions.get('window').width;
const H = Dimensions.get('window').height;

// ─── YOUR ANTHROPIC API KEY ────────────────────────────────────
// Replace with your key from console.anthropic.com
const ANTHROPIC_KEY = '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';

// ─── COLORS ───────────────────────────────────────────────────
const C = {
  sky:'#38BDF8', skyD:'#0369A1', skyL:'#E0F2FE',
  green:'#22C55E', greenD:'#15803D', greenL:'#DCFCE7',
  amber:'#F59E0B', amberL:'#FEF3C7',
  purple:'#A855F7', purpleL:'#F3E8FF',
  red:'#EF4444', redL:'#FEE2E2',
  gold:'#EAB308', muted:'#64748B',
  bg:'#F0F9FF', card:'#FFFFFF', txt:'#0F172A', border:'#E2E8F0',
  coral:'#F97316', coralL:'#FFEDD5',
  navy:'#1E3A5F', navyL:'#E8F0FA',
};

// ─── SEED DATA ─────────────────────────────────────────────────
const INIT_PROFILES = [
  { id:'p1', name:'Alex', age:7, av:'🦁', xp:340, level:4, streak:5 },
  { id:'p2', name:'Mia',  age:5, av:'🦋', xp:120, level:2, streak:2 },
];
const INIT_WORDS = [
  { id:'w1', word:'Apple',    em:'🍎', def:'A round fruit that grows on trees.',         pid:'p1' },
  { id:'w2', word:'Bicycle',  em:'🚲', def:'A two-wheeled vehicle you pedal.',            pid:'p1' },
  { id:'w3', word:'Cloud',    em:'☁️', def:'Fluffy white shapes floating in the sky.',   pid:'p1' },
  { id:'w4', word:'Dog',      em:'🐶', def:'A loyal furry pet that loves to play.',      pid:'p2' },
  { id:'w5', word:'Elephant', em:'🐘', def:'The largest land animal with a long trunk.', pid:'p2' },
  { id:'w6', word:'Flower',   em:'🌸', def:'The colourful beautiful part of a plant.',   pid:'p1' },
];
const BADGES = [
  { id:'b1', icon:'📷', title:'First Scan',     desc:'Scanned first object',   xp:10, done:true  },
  { id:'b2', icon:'📚', title:'Word Collector',  desc:'Learned 10 words',       xp:25, done:true  },
  { id:'b3', icon:'🔥', title:'On a Roll',       desc:'3-day streak',           xp:30, done:true  },
  { id:'b4', icon:'🗺️', title:'Explorer',        desc:'Completed a hunt',       xp:50, done:false },
  { id:'b5', icon:'⚡', title:'Flash Master',    desc:'20 flashcard sessions',  xp:40, done:false },
  { id:'b6', icon:'🏆', title:'Champion',        desc:'Won 5 mini-games',       xp:60, done:false },
];
const HUNTS = [
  { id:'h1', em:'🍳', title:'Kitchen Quest', items:['Spoon','Cup','Plate','Fork','Bowl'] },
  { id:'h2', em:'🌿', title:'Garden Safari', items:['Leaf','Flower','Rock','Stick','Pot'] },
  { id:'h3', em:'🛋️', title:'Room Explorer', items:['Pillow','Lamp','Book','Pen','Chair'] },
];
const DEFAULT_CTRL = {
  screenTimeLimit:30, screenTimeUsed:18,
  allowScanning:true, allowGames:true, allowStories:true, allowFlashcards:true,
  dailyWordGoal:5, locked:false,
};
const INIT_NOTIFS = [
  { id:'n1', pid:'p1', type:'word',   msg:'📖 Alex learned Apple and earned +10 XP!', ts:Date.now()-300000,  read:false },
  { id:'n2', pid:'p1', type:'game',   msg:'🎮 Alex won Balloon Pop with 30 points!',  ts:Date.now()-900000,  read:false },
  { id:'n3', pid:'p2', type:'word',   msg:'📖 Mia learned her first word: Dog!',       ts:Date.now()-1800000, read:true  },
  { id:'n4', pid:'p1', type:'streak', msg:'🔥 Alex is on a 5-day learning streak!',   ts:Date.now()-86400000,read:true  },
];
const INIT_ACTIVITY = [
  { id:'a1', pid:'p1', type:'word',  msg:'Alex learned Apple 🍎',        ts:Date.now()-300000  },
  { id:'a2', pid:'p1', type:'game',  msg:'Alex won Balloon Pop (30pts)',  ts:Date.now()-900000  },
  { id:'a3', pid:'p2', type:'word',  msg:'Mia learned Dog 🐶',           ts:Date.now()-1800000 },
  { id:'a4', pid:'p1', type:'scan',  msg:'Alex scanned an image 📷',     ts:Date.now()-3600000 },
];

function uid() { return Math.random().toString(36).slice(2,8); }
function timeAgo(ts) {
  const d = Date.now()-ts;
  if(d<60000) return 'just now';
  if(d<3600000) return `${Math.floor(d/60000)}m ago`;
  if(d<86400000) return `${Math.floor(d/3600000)}h ago`;
  return `${Math.floor(d/86400000)}d ago`;
}

// ─── VOICE ────────────────────────────────────────────────────
const Voice = {
  speak(text, opts={}) {
    Speech.stop();
    Speech.speak(text, { language:'en', pitch: opts.pitch||1.4, rate: opts.rate||0.9, ...opts });
  },
  celebrate(name, word) {
    const p=[
      `Oh WOW ${name}! You just learned ${word}! That is SO amazing! I am so proud of you!`,
      `YES YES YES ${name}! ${word}! You are absolutely BRILLIANT! High five!`,
      `INCREDIBLE ${name}! ${word}?! You are on FIRE today! Keep going superstar!`,
    ];
    this.speak(p[Math.floor(Math.random()*p.length)], {pitch:1.6, rate:1.0});
  },
  gameWin(name, score) {
    this.speak(`WOOOHOOO ${name}! You scored ${score} points! You are a CHAMPION!`, {pitch:1.7, rate:1.05});
  },
  wrong() {
    const p=["Oops! That's okay! Try again, you've totally got this!","Not quite! Every mistake is learning! Go again superstar!"];
    this.speak(p[Math.floor(Math.random()*p.length)], {pitch:1.3, rate:0.9});
  },
  greet(name) { this.speak(`Welcome back ${name}! Ready for an amazing adventure? Let's GO!`, {pitch:1.5}); },
  scanSuccess(word) { this.speak(`Ooooh! That is a ${word}! How COOL is that! Let me tell you all about it!`, {pitch:1.5}); },
  huntDone(name) { this.speak(`OH WOW ${name}! You found EVERYTHING! Greatest explorer ever! Fifty XP just for you!`, {pitch:1.7}); },
};

// ─── CLAUDE API ───────────────────────────────────────────────
async function callClaude(messages, system='') {
  const key = ANTHROPIC_KEY;
  if(!key || key==='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') throw new Error('NO_KEY');
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method:'POST',
    headers:{'Content-Type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01'},
    body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:800,system,messages}),
  });
  const d = await r.json();
  if(d.error) throw new Error(d.error.message);
  return d.content?.find(b=>b.type==='text')?.text||'';
}

async function analyzeImage(base64) {
  const sys = `You are a children's vocabulary tutor for ages 4-10.
Identify the main object in the image and return ONLY valid JSON (no markdown):
{"word":"Apple","em":"🍎","def":"A round crunchy fruit that grows on trees.","fact":"Apples float in water because 25% of their volume is air!","level":"easy"}
Keep definitions simple. Facts should be surprising and fun for children.`;
  try {
    const raw = await callClaude([{
      role:'user',
      content:[
        {type:'image', source:{type:'base64', media_type:'image/jpeg', data:base64}},
        {type:'text', text:'Identify the main object. Return only the JSON.'}
      ]
    }], sys);
    return JSON.parse(raw.replace(/```json|```/g,'').trim());
  } catch(e) {
    if(e.message==='NO_KEY') throw e;
    return {word:'Mystery Object',em:'❓',def:'Something interesting to discover!',fact:'Everything around us has a name to learn!',level:'easy'};
  }
}

async function buildQuiz(word, def) {
  const sys = `Return ONLY valid JSON no markdown:
{"q":"What do we call a round red fruit?","ans":"Apple","opts":["Apple","Orange","Banana","Grape"]}
opts must contain the answer and 3 wrong options shuffled randomly.`;
  try {
    const raw = await callClaude([{role:'user',content:`Word: ${word}\nDefinition: ${def}`}], sys);
    return JSON.parse(raw.replace(/```json|```/g,'').trim());
  } catch {
    return {q:`What is a "${word}"?`, ans:word, opts:[word,'Cloud','Rock','Leaf'].sort(()=>Math.random()-.5)};
  }
}

async function buildStory(wordList) {
  return callClaude(
    [{role:'user',content:`Write a 4-sentence magical adventure story for a 6-year-old that naturally uses these words: ${wordList}. Make it exciting and fun!`}],
    "You are a master children's storyteller. Keep it immersive and age-appropriate."
  );
}

// ─── SHARED COMPONENTS ────────────────────────────────────────
function Btn({label, onPress, bg, fg='#fff', disabled=false, style}) {
  return (
    <TouchableOpacity onPress={onPress} disabled={disabled} activeOpacity={0.8}
      style={[{backgroundColor:disabled?'#CBD5E1':bg, borderRadius:14, padding:14,
        alignItems:'center', shadowColor:'#000', shadowOpacity:disabled?0:0.15,
        shadowRadius:8, elevation:disabled?0:4}, style]}>
      <Text style={{color:disabled?'#94A3B8':fg, fontSize:15, fontWeight:'800'}}>{label}</Text>
    </TouchableOpacity>
  );
}

function Card({children, onPress, style}) {
  const base = {backgroundColor:C.card, borderRadius:20, padding:18,
    shadowColor:'#000', shadowOpacity:0.07, shadowRadius:10, elevation:3};
  if(onPress) return <TouchableOpacity onPress={onPress} activeOpacity={0.85} style={[base,style]}>{children}</TouchableOpacity>;
  return <View style={[base,style]}>{children}</View>;
}

function Avi({av, size=48}) {
  return (
    <View style={{width:size,height:size,borderRadius:size/2,backgroundColor:'#FCD34D',alignItems:'center',justifyContent:'center'}}>
      <Text style={{fontSize:size*0.52}}>{av}</Text>
    </View>
  );
}

function XPBar({xp, level}) {
  const cap=level*100, pct=Math.min(100,(xp%cap)/cap*100);
  return (
    <View>
      <View style={{flexDirection:'row',justifyContent:'space-between',marginBottom:3}}>
        <Text style={{fontSize:11,color:C.muted}}>Level {level}</Text>
        <Text style={{fontSize:11,color:C.muted}}>{xp%cap}/{cap} XP</Text>
      </View>
      <View style={{height:8,backgroundColor:C.skyL,borderRadius:6}}>
        <View style={{width:`${pct}%`,height:'100%',backgroundColor:C.skyD,borderRadius:6}}/>
      </View>
    </View>
  );
}

function TopBar({title, onBack}) {
  return (
    <View style={{flexDirection:'row',alignItems:'center',padding:16,paddingTop:Platform.OS==='ios'?50:40,backgroundColor:C.bg}}>
      {onBack && <TouchableOpacity onPress={onBack} style={{marginRight:12}}><Text style={{fontSize:24}}>⬅️</Text></TouchableOpacity>}
      <Text style={{fontSize:18,fontWeight:'900',color:C.txt,flex:1}}>{title}</Text>
    </View>
  );
}

function Toggle({on, onToggle}) {
  return (
    <TouchableOpacity onPress={onToggle}
      style={{width:52,height:28,borderRadius:14,backgroundColor:on?C.green:C.border,justifyContent:'center',padding:4}}>
      <View style={{width:20,height:20,borderRadius:10,backgroundColor:'#fff',marginLeft:on?24:0,shadowColor:'#000',shadowOpacity:0.2,shadowRadius:2,elevation:2}}/>
    </TouchableOpacity>
  );
}

function BottomNav({page, go, isChild}) {
  const tabs = isChild ? [
    {id:'ChildHome',icon:'🏠',label:'Home'},
    {id:'Scan',     icon:'📷',label:'Scan'},
    {id:'Cards',    icon:'🃏',label:'Cards'},
    {id:'Games',    icon:'🎮',label:'Games'},
    {id:'Awards',   icon:'🏆',label:'Awards'},
  ] : [
    {id:'ParentHome',   icon:'📊',label:'Home'},
    {id:'Notifications',icon:'🔔',label:'Alerts'},
    {id:'Controls',     icon:'🛡️',label:'Controls'},
    {id:'ActivityLog',  icon:'📋',label:'Activity'},
    {id:'Settings',     icon:'⚙️',label:'Settings'},
  ];
  return (
    <View style={{flexDirection:'row',backgroundColor:'#fff',borderTopWidth:1,borderTopColor:C.border,paddingBottom:Platform.OS==='ios'?24:10,paddingTop:8}}>
      {tabs.map(t=>(
        <TouchableOpacity key={t.id} onPress={()=>go(t.id)} style={{flex:1,alignItems:'center',gap:2}}>
          <Text style={{fontSize:22}}>{t.icon}</Text>
          <Text style={{fontSize:10,fontWeight:'800',color:page===t.id?C.skyD:C.muted}}>{t.label}</Text>
          {page===t.id && <View style={{width:5,height:5,borderRadius:3,backgroundColor:C.skyD}}/>}
        </TouchableOpacity>
      ))}
    </View>
  );
}

function Shell({children, page, go, isChild, showNav=true}) {
  return (
    <SafeAreaView style={{flex:1,backgroundColor:C.bg}}>
      <StatusBar barStyle="dark-content" backgroundColor={C.bg}/>
      <ScrollView style={{flex:1}} showsVerticalScrollIndicator={false}>
        {children}
        <View style={{height:24}}/>
      </ScrollView>
      {showNav && isChild!==null && <BottomNav page={page} go={go} isChild={isChild}/>}
    </SafeAreaView>
  );
}

// ══════════════════════════════════════════════════════════════
// WELCOME
// ══════════════════════════════════════════════════════════════
function Welcome({go, setIsChild}) {
  return (
    <SafeAreaView style={{flex:1,backgroundColor:'#E0F2FE'}}>
      <View style={{flex:1,alignItems:'center',justifyContent:'center',padding:32}}>
        <Text style={{fontSize:80,marginBottom:8}}>🌍</Text>
        <Text style={{fontSize:34,fontWeight:'900',color:C.txt,marginBottom:6}}>
          Word<Text style={{color:C.skyD}}>Wanderer</Text>
        </Text>
        <Text style={{color:C.muted,fontSize:16,textAlign:'center',maxWidth:280,lineHeight:24,marginBottom:44}}>
          AI-powered vocabulary adventures — scan the world and learn English! 🔍
        </Text>
        <View style={{width:'100%',maxWidth:300,gap:14}}>
          <Btn label="🦁  I'm a Kid!" bg={C.skyD} style={{padding:18,marginBottom:14}}
            onPress={()=>{setIsChild(true);go('ChildHome');}}/>
          <Btn label="👨‍👩‍👧  Parent / Guardian" bg={C.greenD} style={{padding:18}}
            onPress={()=>{setIsChild(false);go('ParentHome');}}/>
        </View>
        <Text style={{color:C.muted,fontSize:11,marginTop:28}}>Supervised learning · Ages 4–10</Text>
      </View>
    </SafeAreaView>
  );
}

// ══════════════════════════════════════════════════════════════
// CHILD HOME
// ══════════════════════════════════════════════════════════════
function ChildHome({go, page, isChild, profiles, pid, words, controls}) {
  const p = profiles.find(x=>x.id===pid)||profiles[0];
  const cfg = controls[pid]||DEFAULT_CTRL;
  const mine = words.filter(w=>w.pid===p.id);

  useEffect(()=>{ Voice.greet(p.name); },[p.id]);

  if(cfg.locked) return (
    <Shell page={page} go={go} isChild={isChild}>
      <View style={{alignItems:'center',padding:80}}>
        <Text style={{fontSize:72}}>🔒</Text>
        <Text style={{fontSize:22,fontWeight:'900',color:C.txt,marginTop:16}}>App Locked</Text>
        <Text style={{color:C.muted,textAlign:'center',marginTop:8,lineHeight:22}}>
          Your parent has locked this account. Ask them to unlock it!
        </Text>
      </View>
    </Shell>
  );

  return (
    <Shell page={page} go={go} isChild={isChild}>
      <View style={{backgroundColor:C.skyD,padding:24,paddingTop:48,borderBottomLeftRadius:32,borderBottomRightRadius:32}}>
        <View style={{flexDirection:'row',alignItems:'center',gap:14}}>
          <Avi av={p.av} size={56}/>
          <View style={{flex:1}}>
            <Text style={{color:'#fff',opacity:0.85,fontSize:13}}>Hello,</Text>
            <Text style={{color:'#fff',fontSize:22,fontWeight:'900'}}>{p.name}! 👋</Text>
          </View>
          <View style={{alignItems:'center'}}>
            <Text style={{fontSize:26}}>🔥</Text>
            <Text style={{color:'#fff',fontSize:11,fontWeight:'800'}}>{p.streak} day streak</Text>
          </View>
        </View>
        <View style={{marginTop:16}}><XPBar xp={p.xp} level={p.level}/></View>
        <Text style={{color:'#fff',opacity:0.75,fontSize:11,marginTop:8}}>
          ⏱️ {cfg.screenTimeUsed}/{cfg.screenTimeLimit} min today · 🎯 Goal: {cfg.dailyWordGoal} words
        </Text>
      </View>

      <View style={{padding:18}}>
        <View style={{flexDirection:'row',gap:10,marginBottom:18}}>
          {[{i:'📖',v:mine.length,l:'Words'},{i:'⭐',v:p.level,l:'Level'},{i:'✨',v:p.xp,l:'XP'}].map(s=>(
            <Card key={s.l} style={{flex:1,alignItems:'center',padding:12}}>
              <Text style={{fontSize:22}}>{s.i}</Text>
              <Text style={{fontSize:20,fontWeight:'900',color:C.txt}}>{s.v}</Text>
              <Text style={{fontSize:10,color:C.muted}}>{s.l}</Text>
            </Card>
          ))}
        </View>

        <Text style={{fontSize:17,fontWeight:'900',color:C.txt,marginBottom:12}}>What do you want to do? 🎉</Text>

        <View style={{flexDirection:'row',flexWrap:'wrap',gap:12,marginBottom:14}}>
          {[
            {icon:'📷',label:'Scan Object',   bg:C.skyL,   ac:C.skyD,   pg:'Scan',  ok:cfg.allowScanning},
            {icon:'🃏',label:'Flashcards',    bg:C.amberL, ac:'#B45309', pg:'Cards', ok:cfg.allowFlashcards},
            {icon:'🎮',label:'Play Games',    bg:C.purpleL,ac:'#7E22CE', pg:'Games', ok:cfg.allowGames},
            {icon:'🗺️',label:'Scavenger Hunt',bg:C.greenL, ac:C.greenD,  pg:'Hunt',  ok:true},
          ].map(a=>(
            <TouchableOpacity key={a.label} onPress={a.ok?()=>go(a.pg):undefined} activeOpacity={0.85}
              style={{width:(W-48)/2,backgroundColor:a.ok?a.bg:'#F1F5F9',borderRadius:20,padding:16,
                opacity:a.ok?1:0.55,shadowColor:'#000',shadowOpacity:0.06,shadowRadius:8,elevation:2}}>
              <Text style={{fontSize:34,marginBottom:6}}>{a.icon}</Text>
              <Text style={{fontSize:14,fontWeight:'800',color:a.ok?a.ac:C.muted}}>{a.label}</Text>
              {!a.ok&&<Text style={{fontSize:10,color:C.muted,marginTop:2}}>🔒 Locked by parent</Text>}
            </TouchableOpacity>
          ))}
        </View>

        {cfg.allowStories && (
          <Card onPress={()=>go('Story')} style={{backgroundColor:'#F3E8FF',marginBottom:14}}>
            <View style={{flexDirection:'row',alignItems:'center',gap:14}}>
              <Text style={{fontSize:36}}>📖</Text>
              <View>
                <Text style={{fontSize:15,fontWeight:'800',color:C.txt}}>Story Time!</Text>
                <Text style={{color:C.muted,fontSize:13}}>Make a magical story with your words</Text>
              </View>
            </View>
          </Card>
        )}

        {mine.length>0 && (
          <>
            <Text style={{fontSize:17,fontWeight:'900',color:C.txt,marginBottom:10}}>Words I Know 📚</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {mine.slice(-8).map(w=>(
                <View key={w.id} style={{backgroundColor:'#fff',borderRadius:14,padding:12,marginRight:10,
                  alignItems:'center',minWidth:70,shadowColor:'#000',shadowOpacity:0.06,shadowRadius:6,elevation:2}}>
                  <Text style={{fontSize:26}}>{w.em}</Text>
                  <Text style={{fontSize:11,fontWeight:'700',color:C.txt,marginTop:2}}>{w.word}</Text>
                </View>
              ))}
            </ScrollView>
          </>
        )}
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// SCAN — REAL CAMERA
// ══════════════════════════════════════════════════════════════
function ScanScreen({go, page, isChild, addWord, pid, setLast, profiles, addActivity, addNotif, controls}) {
  const p = profiles.find(x=>x.id===pid)||profiles[0];
  const cfg = controls[pid]||DEFAULT_CTRL;
  const [hasPermission, setHasPermission] = useState(null);
  const [showCamera, setShowCamera] = useState(false);
  const [phase, setPhase] = useState('idle'); // idle|busy|result
  const [result, setResult] = useState(null);
  const [story, setStory] = useState('');
  const cameraRef = useRef(null);

  useEffect(()=>{
    (async()=>{
      const {status} = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status==='granted');
    })();
  },[]);

  async function handleImage(base64) {
    setShowCamera(false);
    setPhase('busy'); setResult(null); setStory('');
    try {
      const hasKey = ANTHROPIC_KEY && ANTHROPIC_KEY!=='';
      let data;
      if(hasKey) {
        data = await analyzeImage(base64);
        Voice.scanSuccess(data.word);
      } else {
        // Demo fallback
        await new Promise(r=>setTimeout(r,1500));
        data = {word:'Sunflower',em:'🌻',def:'A tall plant with a bright yellow flower that follows the sun.',fact:'Sunflowers can grow taller than 3 metres — taller than most grown-ups!',level:'easy'};
        Voice.scanSuccess(data.word);
      }
      setResult(data);
      setPhase('result');
      // Generate story
      if(hasKey) {
        const s = await buildStory(data.word);
        setStory(s);
      } else {
        setStory(`Once upon a time, a brave explorer discovered a magical ${data.word} in an enchanted forest. A friendly elephant helped carry it home through the clouds. Together they shared it with all their friends and everyone celebrated with joy. And they all lived happily ever after! 🌟`);
      }
    } catch(e) {
      setPhase('idle');
      Alert.alert('Oops!', e.message==='NO_KEY'
        ? 'Add your Anthropic API key to the app for real AI scanning.'
        : 'Could not analyse the image. Please try again!');
    }
  }

  async function takePicture() {
    if(!cameraRef.current) return;
    try {
      const photo = await cameraRef.current.takePictureAsync({base64:true,quality:0.7});
      await handleImage(photo.base64);
    } catch(e) { Alert.alert('Error','Could not take photo. Please try again.'); }
  }

  async function pickFromGallery() {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes:ImagePicker.MediaTypeOptions.Images,
      base64:true, quality:0.7,
    });
    if(!result.canceled && result.assets[0]) {
      await handleImage(result.assets[0].base64);
    }
  }

  function save() {
    const w = {id:uid(),...result,pid};
    addWord(w); setLast(w);
    Voice.celebrate(p.name, result.word);
    addActivity({id:uid(),pid,type:'word',msg:`${p.name} learned '${result.word}' ${result.em}`,ts:Date.now()});
    if(cfg.notifyOnWordLearned!==false)
      addNotif({id:uid(),pid,type:'word',msg:`📖 ${p.name} just learned '${result.word}' ${result.em} and earned +10 XP!`,ts:Date.now(),read:false});
    go('Result');
  }

  // Camera view
  if(showCamera) return (
    <View style={{flex:1,backgroundColor:'#000'}}>
      <Camera ref={cameraRef} style={{flex:1}} type={CameraType.back}>
        <View style={{flex:1,justifyContent:'flex-end',padding:32,alignItems:'center'}}>
          <TouchableOpacity onPress={takePicture}
            style={{width:80,height:80,borderRadius:40,backgroundColor:'#fff',alignItems:'center',justifyContent:'center',
              shadowColor:'#000',shadowOpacity:0.4,shadowRadius:12,elevation:8}}>
            <Text style={{fontSize:36}}>📷</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={()=>setShowCamera(false)} style={{marginTop:20}}>
            <Text style={{color:'#fff',fontSize:16,fontWeight:'700'}}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </Camera>
    </View>
  );

  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="📷 Scan Object" onBack={()=>go('ChildHome')}/>
      <View style={{padding:18}}>

        {phase==='idle' && (
          <>
            <View style={{backgroundColor:C.skyL,borderRadius:24,padding:28,alignItems:'center',marginBottom:20,borderWidth:3,borderColor:'#93C5FD',borderStyle:'dashed'}}>
              <Text style={{fontSize:68,marginBottom:10}}>📷</Text>
              <Text style={{fontSize:18,fontWeight:'900',color:C.txt,marginBottom:6,textAlign:'center'}}>
                Scan anything to learn its name!
              </Text>
              <Text style={{color:C.muted,fontSize:14,textAlign:'center'}}>
                Point at a toy, fruit, animal, or any object 🌟
              </Text>
            </View>

            {hasPermission===false && (
              <Card style={{backgroundColor:C.redL,marginBottom:14}}>
                <Text style={{color:C.red,fontWeight:'700',fontSize:13}}>
                  📷 Camera permission denied. Please allow camera access in your phone settings.
                </Text>
              </Card>
            )}

            {ANTHROPIC_KEY==='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' && (
              <Card style={{backgroundColor:C.amberL,marginBottom:14}}>
                <Text style={{color:'#92400E',fontWeight:'700',fontSize:12}}>
                  🟡 Demo mode: Add your Anthropic API key in App.js for real AI scanning.
                </Text>
              </Card>
            )}

            <View style={{gap:12}}>
              <Btn label="📸 Open Camera" bg={C.skyD} style={{padding:18}}
                onPress={()=>{ if(hasPermission) setShowCamera(true); else Alert.alert('Permission needed','Please allow camera access in settings'); }}/>
              <Btn label="🖼️ Choose from Gallery" bg={C.greenD} style={{padding:18}}
                onPress={pickFromGallery}/>
            </View>

            <Card style={{marginTop:18,backgroundColor:C.amberL}}>
              <Text style={{fontSize:12,color:'#78350F',fontWeight:'700'}}>
                💡 Parents: supervise scanning. All AI responses are filtered for ages 4–10.
              </Text>
            </Card>
          </>
        )}

        {phase==='busy' && (
          <View style={{alignItems:'center',paddingTop:60,gap:20}}>
            <Text style={{fontSize:64}}>🔍</Text>
            <ActivityIndicator size="large" color={C.skyD}/>
            <Text style={{color:C.muted,fontSize:16,textAlign:'center'}}>
              Analysing your image…{'\n'}This is so exciting! ✨
            </Text>
          </View>
        )}

        {phase==='result' && result && (
          <>
            <Card style={{alignItems:'center',marginBottom:14,backgroundColor:C.skyL}}>
              <Text style={{fontSize:76,marginBottom:8}}>{result.em}</Text>
              <Text style={{fontSize:32,fontWeight:'900',color:C.txt,marginBottom:8}}>{result.word}</Text>
              <View style={{backgroundColor:C.amber,borderRadius:20,paddingHorizontal:14,paddingVertical:3}}>
                <Text style={{color:'#fff',fontSize:11,fontWeight:'800'}}>{(result.level||'easy').toUpperCase()}</Text>
              </View>
            </Card>

            <Card style={{marginBottom:12}}>
              <Text style={{fontSize:11,color:C.skyD,fontWeight:'800',marginBottom:5}}>📖 WHAT IS IT?</Text>
              <Text style={{fontSize:15,color:C.txt,lineHeight:22}}>{result.def}</Text>
            </Card>

            {result.fact && (
              <Card style={{marginBottom:12,backgroundColor:C.amberL}}>
                <Text style={{fontSize:11,color:'#B45309',fontWeight:'800',marginBottom:5}}>🌟 FUN FACT</Text>
                <Text style={{fontSize:14,color:C.txt,lineHeight:22}}>{result.fact}</Text>
              </Card>
            )}

            {story ? (
              <Card style={{marginBottom:18,backgroundColor:C.purpleL}}>
                <Text style={{fontSize:11,color:'#7E22CE',fontWeight:'800',marginBottom:5}}>📖 MINI STORY</Text>
                <Text style={{fontSize:14,color:C.txt,lineHeight:22,fontStyle:'italic'}}>{story}</Text>
                <TouchableOpacity onPress={()=>Voice.speak(story,{pitch:1.4,rate:0.88})}
                  style={{marginTop:10,backgroundColor:C.purple,borderRadius:10,padding:8,alignItems:'center'}}>
                  <Text style={{color:'#fff',fontWeight:'800',fontSize:12}}>🔊 Read Story Aloud</Text>
                </TouchableOpacity>
              </Card>
            ) : (
              <View style={{marginBottom:18,alignItems:'center',padding:20}}>
                <ActivityIndicator color={C.purple}/>
                <Text style={{color:C.muted,fontSize:13,marginTop:8}}>Writing your story…</Text>
              </View>
            )}

            <View style={{flexDirection:'row',gap:10}}>
              <Btn label="✅ Save Word!" bg={C.greenD} style={{flex:1}} onPress={save}/>
              <Btn label="🔄 Scan Again" bg={C.muted} style={{flex:1}}
                onPress={()=>{setPhase('idle');setResult(null);setStory('');}}/>
            </View>
          </>
        )}
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// RESULT
// ══════════════════════════════════════════════════════════════
function ResultScreen({go, page, isChild, last, profiles, pid}) {
  const p = profiles.find(x=>x.id===pid)||profiles[0];
  const w = last||{word:'Object',em:'📦',def:'Something you scanned!'};
  return (
    <Shell page={page} go={go} isChild={isChild} showNav={false}>
      <View style={{flex:1,backgroundColor:C.greenL,alignItems:'center',justifyContent:'center',padding:28,minHeight:H*0.9}}>
        <Text style={{fontSize:76}}>🎉</Text>
        <Text style={{fontSize:28,fontWeight:'900',color:C.txt,marginTop:8}}>Amazing, {p.name}!</Text>
        <Text style={{color:C.muted,marginBottom:22,marginTop:4}}>You just learned a new word!</Text>
        <Card style={{width:'100%',maxWidth:320,marginBottom:22,backgroundColor:C.skyL,alignItems:'center'}}>
          <Text style={{fontSize:68,marginBottom:6}}>{w.em}</Text>
          <Text style={{fontSize:28,fontWeight:'900',color:C.txt,marginBottom:6}}>{w.word}</Text>
          <Text style={{color:C.muted,fontSize:14,textAlign:'center'}}>{w.def}</Text>
        </Card>
        <View style={{flexDirection:'row',gap:14,marginBottom:28}}>
          {[{i:'⭐',v:'+10',l:'XP Earned'},{i:'📚',v:'+1',l:'Word Added'}].map(s=>(
            <View key={s.l} style={{backgroundColor:'#fff',borderRadius:16,padding:16,alignItems:'center',
              shadowColor:'#000',shadowOpacity:0.08,shadowRadius:8,elevation:3}}>
              <Text style={{fontSize:26}}>{s.i}</Text>
              <Text style={{fontSize:20,fontWeight:'900',color:C.skyD}}>{s.v}</Text>
              <Text style={{fontSize:11,color:C.muted}}>{s.l}</Text>
            </View>
          ))}
        </View>
        <View style={{width:'100%',maxWidth:280,gap:12}}>
          <Btn label="📷 Scan Another!" bg={C.skyD} style={{padding:16}} onPress={()=>go('Scan')}/>
          <Btn label="🎮 Play a Game!" bg={C.purple} style={{padding:16}} onPress={()=>go('Games')}/>
          <Btn label="Back to Home" bg="transparent" fg={C.muted} style={{shadowOpacity:0}} onPress={()=>go('ChildHome')}/>
        </View>
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// FLASHCARDS
// ══════════════════════════════════════════════════════════════
function FlashCards({go, page, isChild, words, pid}) {
  const mine = words.filter(w=>w.pid===pid);
  const [idx, setIdx] = useState(0);
  const [flip, setFlip] = useState(false);
  const [seen, setSeen] = useState(new Set());

  if(!mine.length) return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="🃏 Flashcards" onBack={()=>go('ChildHome')}/>
      <View style={{alignItems:'center',padding:60}}>
        <Text style={{fontSize:60}}>📷</Text>
        <Text style={{fontSize:20,fontWeight:'900',color:C.txt,marginTop:16}}>No words yet!</Text>
        <Text style={{color:C.muted,marginBottom:20,marginTop:4}}>Scan some objects first.</Text>
        <Btn label="Go Scan! 📷" bg={C.skyD} onPress={()=>go('Scan')}/>
      </View>
    </Shell>
  );

  const card = mine[idx];
  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="🃏 Flashcards" onBack={()=>go('ChildHome')}/>
      <View style={{padding:18}}>
        <View style={{flexDirection:'row',justifyContent:'space-between',marginBottom:6}}>
          <Text style={{fontSize:12,color:C.muted}}>Card {idx+1} of {mine.length}</Text>
          <Text style={{fontSize:12,color:C.muted}}>{seen.size} reviewed ✓</Text>
        </View>
        <View style={{height:8,backgroundColor:C.skyL,borderRadius:6,marginBottom:20}}>
          <View style={{width:`${(seen.size/mine.length)*100}%`,height:'100%',backgroundColor:C.skyD,borderRadius:6}}/>
        </View>
        <TouchableOpacity onPress={()=>setFlip(f=>!f)} activeOpacity={0.9}
          style={{backgroundColor:flip?C.purpleL:C.skyL,borderRadius:28,padding:36,alignItems:'center',
            minHeight:210,justifyContent:'center',shadowColor:'#000',shadowOpacity:0.1,shadowRadius:16,elevation:6}}>
          <Text style={{fontSize:76,marginBottom:14}}>{card.em}</Text>
          {!flip
            ? <><Text style={{fontSize:32,fontWeight:'900',color:C.txt,marginBottom:10}}>{card.word}</Text>
                <Text style={{color:C.muted,fontSize:13}}>Tap to reveal 👇</Text></>
            : <><Text style={{fontSize:16,color:C.txt,lineHeight:24,marginBottom:8,textAlign:'center'}}>{card.def}</Text>
                <Text style={{fontSize:12,color:C.skyD,fontWeight:'800'}}>📖 {card.word}</Text></>
          }
        </TouchableOpacity>
        <View style={{flexDirection:'row',gap:10,marginTop:18}}>
          <Btn label="← Prev" bg={C.redL} fg={C.red} style={{flex:1}}
            onPress={()=>{setFlip(false);setIdx(i=>(i-1+mine.length)%mine.length);}}/>
          <Btn label="Next →" bg={C.skyD} style={{flex:2}}
            onPress={()=>{setSeen(s=>new Set([...s,idx]));setFlip(false);setIdx(i=>(i+1)%mine.length);}}/>
        </View>
        <TouchableOpacity onPress={()=>Voice.speak(`${card.word}. ${card.def}`,{pitch:1.4,rate:0.85})}
          style={{marginTop:12,backgroundColor:C.purpleL,borderRadius:12,padding:12,alignItems:'center'}}>
          <Text style={{color:C.purple,fontWeight:'800',fontSize:13}}>🔊 Hear this word</Text>
        </TouchableOpacity>
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// GAMES HUB
// ══════════════════════════════════════════════════════════════
function GamesHub({go, page, isChild, words, pid, profiles, addActivity, addNotif, controls}) {
  const p = profiles.find(x=>x.id===pid)||profiles[0];
  const [active, setActive] = useState(null);
  const mine = words.filter(w=>w.pid===pid);
  const pool = mine.length>=4 ? mine : [...mine,...INIT_WORDS].slice(0,8);

  // ── Balloon Pop state ──
  const [score,  setScore]  = useState(0);
  const [lives,  setLives]  = useState(3);
  const [round,  setRound]  = useState(0);
  const [target, setTarget] = useState(null);
  const [balloons,setBalloons]=useState([]);
  const [popped, setPopped] = useState(null);

  function startBalloon() { setActive('balloon');setScore(0);setLives(3);setRound(0);newBalloon(pool); }
  function newBalloon(pl) {
    const sh=[...pl].sort(()=>Math.random()-0.5).slice(0,4);
    const cor=sh[Math.floor(Math.random()*sh.length)];
    setTarget(cor);setPopped(null);
    setBalloons(sh.map((w,i)=>({id:uid(),word:w,color:[C.sky,C.amber,C.purple,C.coral][i]})));
  }
  function popBalloon(bal) {
    if(popped) return;
    const ok=bal.word.word===target.word;
    setPopped(bal.id);
    if(ok){
      const ns=score+10;setScore(ns);
      Voice.celebrate(p.name,target.word);
      setTimeout(()=>{setRound(r=>r+1);newBalloon(pool);},1500);
    } else {
      Voice.wrong();
      const nl=lives-1;setLives(nl);
      if(nl<=0){setTimeout(()=>endGame(score),1000);return;}
      setTimeout(()=>{setRound(r=>r+1);newBalloon(pool);},1500);
    }
  }

  // ── Memory Match state ──
  function makeCards() {
    return pool.slice(0,6).flatMap(w=>[
      {id:uid(),pairId:w.id,type:'word', content:w.word,bg:C.skyL},
      {id:uid(),pairId:w.id,type:'emoji',content:w.em,  bg:C.amberL},
    ]).sort(()=>Math.random()-0.5);
  }
  const [memCards, setMemCards]=useState(makeCards);
  const [flipped,  setFlipped] =useState([]);
  const [matched,  setMatched] =useState([]);
  const [memMoves, setMemMoves]=useState(0);
  const [memLocked,setMemLocked]=useState(false);

  function flipCard(card) {
    if(memLocked||flipped.includes(card.id)||matched.includes(card.pairId)) return;
    const nf=[...flipped,card.id];setFlipped(nf);
    if(nf.length===2){
      setMemMoves(m=>m+1);setMemLocked(true);
      const [a,b]=nf.map(id=>memCards.find(c=>c.id===id));
      if(a.pairId===b.pairId){
        const nm=[...matched,a.pairId];setMatched(nm);setFlipped([]);setMemLocked(false);
        Voice.celebrate(p.name,a.type==='word'?a.content:b.content);
        if(nm.length===pool.slice(0,6).length){
          const s=Math.max(0,100-memMoves*5);
          setTimeout(()=>endGame(s),600);
        }
      } else {
        Voice.wrong();
        setTimeout(()=>{setFlipped([]);setMemLocked(false);},900);
      }
    }
  }

  // ── Quiz state ──
  const [quizWord,setQuizWord]=useState(()=>pool[0]);
  const [quizOpts,setQuizOpts]=useState([]);
  const [quizSel, setQuizSel] =useState(null);
  const [quizScore,setQuizScore]=useState(0);
  const [quizRound,setQuizRound]=useState(0);
  const [quizLoading,setQuizLoading]=useState(false);

  async function loadQuiz(w) {
    setQuizLoading(true);setQuizSel(null);
    const hasKey=ANTHROPIC_KEY&&ANTHROPIC_KEY!=='';
    let q;
    if(hasKey){q=await buildQuiz(w.word,w.def);}
    else{q={q:`What is a "${w.word}"?`,ans:w.word,opts:[w.word,...pool.filter(x=>x.word!==w.word).slice(0,3).map(x=>x.word)].sort(()=>Math.random()-0.5)};}
    setQuizOpts(q.opts||[]);setQuizLoading(false);
    return q;
  }
  const [quizData,setQuizData]=useState(null);

  async function startQuiz() {
    setActive('quiz');setQuizScore(0);setQuizRound(0);
    const w=pool[Math.floor(Math.random()*pool.length)];
    setQuizWord(w);
    const q=await loadQuiz(w);
    setQuizData(q);
  }

  async function answerQuiz(opt) {
    if(quizSel) return;
    setQuizSel(opt);
    const correct=quizData?.ans===opt;
    if(correct){setQuizScore(s=>s+10);Voice.celebrate(p.name,quizWord.word);}
    else{Voice.wrong();}
    setTimeout(async()=>{
      setQuizRound(r=>r+1);
      const w=pool[Math.floor(Math.random()*pool.length)];
      setQuizWord(w);
      const q=await loadQuiz(w);
      setQuizData(q);
    },1400);
  }

  function endGame(finalScore) {
    Voice.gameWin(p.name,finalScore);
    addActivity({id:uid(),pid,type:'game',msg:`${p.name} played a game and scored ${finalScore} points! 🎮`,ts:Date.now()});
    addNotif({id:uid(),pid,type:'game',msg:`🎮 ${p.name} scored ${finalScore} points in a game! Great job!`,ts:Date.now(),read:false});
    Alert.alert('🏆 Game Over!',`Amazing! You scored ${finalScore} points!`,[{text:'Woohoo!',onPress:()=>setActive(null)}]);
  }

  // Game screens
  if(active==='balloon') return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="🎈 Balloon Pop" onBack={()=>setActive(null)}/>
      <View style={{padding:18}}>
        <View style={{flexDirection:'row',justifyContent:'space-between',marginBottom:12}}>
          <View style={{flexDirection:'row',gap:4}}>
            {[...Array(3)].map((_,i)=><Text key={i} style={{fontSize:22}}>{i<lives?'❤️':'🖤'}</Text>)}
          </View>
          <Text style={{fontWeight:'900',color:C.skyD,fontSize:18}}>⭐ {score}</Text>
          <Text style={{color:C.muted,fontSize:13}}>Round {round+1}</Text>
        </View>
        {target && (
          <Card style={{backgroundColor:C.skyL,alignItems:'center',marginBottom:16}}>
            <Text style={{fontSize:12,color:C.muted,fontWeight:'700',marginBottom:4}}>POP THE BALLOON:</Text>
            <View style={{flexDirection:'row',alignItems:'center',gap:10}}>
              <Text style={{fontSize:36}}>{target.em}</Text>
              <Text style={{fontSize:24,fontWeight:'900',color:C.txt}}>{target.word}</Text>
            </View>
          </Card>
        )}
        <View style={{flexDirection:'row',flexWrap:'wrap',gap:16,justifyContent:'center',paddingVertical:20}}>
          {balloons.map(b=>(
            <TouchableOpacity key={b.id} onPress={()=>popBalloon(b)} activeOpacity={0.7}>
              <View style={{alignItems:'center'}}>
                <Text style={{fontSize:popped===b.id?64:52,marginBottom:4}}>
                  {popped===b.id?(b.word.word===target?.word?'💥':'💨'):'🎈'}
                </Text>
                <View style={{backgroundColor:b.color,borderRadius:12,paddingHorizontal:12,paddingVertical:5}}>
                  <Text style={{color:'#fff',fontSize:13,fontWeight:'800'}}>{b.word.word}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </View>
        <Text style={{textAlign:'center',color:C.muted,fontSize:12,marginTop:8}}>
          Tap the balloon matching the word above! 🎈
        </Text>
      </View>
    </Shell>
  );

  if(active==='memory') return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="🧠 Memory Match" onBack={()=>setActive(null)}/>
      <View style={{padding:18}}>
        <View style={{flexDirection:'row',justifyContent:'space-between',marginBottom:12}}>
          <Text style={{color:C.muted,fontSize:13}}>Moves: {memMoves}</Text>
          <Text style={{color:C.green,fontWeight:'800',fontSize:13}}>{matched.length}/{pool.slice(0,6).length} matched ✓</Text>
        </View>
        <Card style={{backgroundColor:C.purpleL,alignItems:'center',marginBottom:14,padding:12}}>
          <Text style={{fontSize:13,color:C.muted,fontWeight:'700'}}>Match each word to its emoji! Tap to flip 🃏</Text>
        </Card>
        <View style={{flexDirection:'row',flexWrap:'wrap',gap:8,justifyContent:'center'}}>
          {memCards.map(card=>{
            const isF=flipped.includes(card.id)||matched.includes(card.pairId);
            const isM=matched.includes(card.pairId);
            return (
              <TouchableOpacity key={card.id} onPress={()=>flipCard(card)} activeOpacity={0.8}
                style={{width:(W-52)/4,height:70,borderRadius:14,
                  backgroundColor:isF?card.bg:'#6366F1',
                  alignItems:'center',justifyContent:'center',
                  borderWidth:isM?2:0,borderColor:C.green}}>
                <Text style={{fontSize:card.type==='emoji'?24:10,fontWeight:'900',
                  color:card.type==='word'?C.txt:'#fff',textAlign:'center',padding:2}}>
                  {isF?card.content:'?'}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>
    </Shell>
  );

  if(active==='quiz') return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="❓ Word Quiz" onBack={()=>setActive(null)}/>
      <View style={{padding:18}}>
        <View style={{flexDirection:'row',justifyContent:'space-between',marginBottom:14}}>
          <Text style={{color:C.muted,fontSize:13}}>Round {quizRound+1}</Text>
          <Text style={{color:C.green,fontWeight:'800',fontSize:13}}>⭐ {quizScore} pts</Text>
        </View>
        {quizLoading || !quizData ? (
          <View style={{alignItems:'center',padding:40,gap:16}}>
            <ActivityIndicator size="large" color={C.skyD}/>
            <Text style={{color:C.muted}}>Generating question…</Text>
          </View>
        ) : (
          <>
            <Card style={{backgroundColor:C.skyL,alignItems:'center',marginBottom:18}}>
              <Text style={{fontSize:56,marginBottom:8}}>{quizWord?.em}</Text>
              <Text style={{fontSize:17,fontWeight:'800',color:C.txt,textAlign:'center'}}>
                {quizData.q||`What is a "${quizWord?.word}"?`}
              </Text>
            </Card>
            <View style={{gap:10}}>
              {(quizData.opts||quizOpts).map(opt=>{
                let bg='#fff', border=C.border;
                if(quizSel){
                  if(opt===quizData.ans){bg=C.greenL;border=C.green;}
                  else if(opt===quizSel){bg=C.redL;border=C.red;}
                }
                return (
                  <TouchableOpacity key={opt} onPress={()=>answerQuiz(opt)} activeOpacity={0.85}
                    style={{backgroundColor:bg,borderWidth:2,borderColor:border,borderRadius:14,padding:15}}>
                    <Text style={{fontSize:15,fontWeight:'800',color:C.txt}}>
                      {opt}{quizSel&&opt===quizData.ans?' ✅':''}{quizSel&&opt===quizSel&&opt!==quizData.ans?' ❌':''}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </>
        )}
      </View>
    </Shell>
  );

  // Games Hub menu
  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="🎮 Games" onBack={()=>go('ChildHome')}/>
      <View style={{padding:18}}>
        <Text style={{color:C.muted,fontSize:14,marginBottom:16}}>Pick a game and start playing! 🌟</Text>
        <View style={{flexDirection:'row',flexWrap:'wrap',gap:12,marginBottom:18}}>
          {[
            {icon:'🎈',title:'Balloon Pop',   desc:'Pop the right balloon!', bg:C.skyL,   action:startBalloon},
            {icon:'🧠',title:'Memory Match',  desc:'Match words to emojis!', bg:C.purpleL,action:()=>{setMemCards(makeCards());setFlipped([]);setMatched([]);setMemMoves(0);setActive('memory');}},
            {icon:'❓',title:'Word Quiz',      desc:'AI quiz questions!',     bg:C.greenL, action:startQuiz},
          ].map(g=>(
            <TouchableOpacity key={g.title} onPress={g.action} activeOpacity={0.85}
              style={{width:(W-48)/2,backgroundColor:g.bg,borderRadius:20,padding:16,alignItems:'center',
                shadowColor:'#000',shadowOpacity:0.06,shadowRadius:8,elevation:2}}>
              <Text style={{fontSize:38,marginBottom:6}}>{g.icon}</Text>
              <Text style={{fontSize:14,fontWeight:'900',color:C.txt}}>{g.title}</Text>
              <Text style={{fontSize:11,color:C.muted,marginTop:3,textAlign:'center'}}>{g.desc}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <Card style={{backgroundColor:C.greenL}}>
          <Text style={{color:C.greenD,fontWeight:'800',fontSize:14}}>
            🏆 Games use words you've scanned — the more you scan the better they get!
          </Text>
        </Card>
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// AWARDS
// ══════════════════════════════════════════════════════════════
function AwardsScreen({go, page, isChild}) {
  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="🏆 Achievements" onBack={()=>go('ChildHome')}/>
      <View style={{padding:18}}>
        <Text style={{color:C.muted,fontSize:14,marginBottom:16}}>{BADGES.filter(b=>b.done).length} of {BADGES.length} earned</Text>
        <View style={{flexDirection:'row',flexWrap:'wrap',gap:12}}>
          {BADGES.map(b=>(
            <View key={b.id} style={{width:(W-48)/2,backgroundColor:b.done?C.amberL:'#F1F5F9',
              borderRadius:20,padding:16,alignItems:'center',opacity:b.done?1:0.5}}>
              <Text style={{fontSize:38,marginBottom:7}}>{b.icon}</Text>
              <Text style={{fontSize:13,fontWeight:'900',color:C.txt}}>{b.title}</Text>
              <Text style={{fontSize:11,color:C.muted,marginVertical:3,textAlign:'center'}}>{b.desc}</Text>
              <Text style={{fontSize:12,color:C.gold,fontWeight:'800'}}>+{b.xp} XP</Text>
              {b.done&&<Text style={{fontSize:10,color:C.green,fontWeight:'800',marginTop:3}}>✓ EARNED</Text>}
            </View>
          ))}
        </View>
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// HUNT
// ══════════════════════════════════════════════════════════════
function HuntScreen({go, page, isChild, profiles, pid, addActivity, addNotif}) {
  const p = profiles.find(x=>x.id===pid)||profiles[0];
  const [active, setActive]=useState(null);
  const [found,  setFound] =useState({});
  const [prog,   setProg]  =useState({h1:2,h2:0,h3:5});

  if(!active) return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="🗺️ Scavenger Hunt" onBack={()=>go('ChildHome')}/>
      <View style={{padding:18}}>
        <Text style={{color:C.muted,fontSize:14,marginBottom:16}}>Choose a hunt to start your adventure!</Text>
        {HUNTS.map(h=>{
          const c=prog[h.id]||0;
          return (
            <Card key={h.id} onPress={()=>{setActive(h);setFound({});}} style={{marginBottom:14}}>
              <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}>
                <View style={{flexDirection:'row',alignItems:'center',gap:12}}>
                  <Text style={{fontSize:36}}>{h.em}</Text>
                  <View>
                    <Text style={{fontSize:16,fontWeight:'800',color:C.txt}}>{h.title}</Text>
                    <Text style={{color:C.muted,fontSize:13}}>{h.items.length} items to find</Text>
                  </View>
                </View>
                <Text style={{fontSize:18,fontWeight:'900',color:c===h.items.length?C.green:C.skyD}}>{c}/{h.items.length}</Text>
              </View>
              <View style={{height:6,backgroundColor:C.skyL,borderRadius:4,marginTop:10}}>
                <View style={{width:`${(c/h.items.length)*100}%`,height:'100%',backgroundColor:C.skyD,borderRadius:4}}/>
              </View>
            </Card>
          );
        })}
      </View>
    </Shell>
  );

  const allDone=active.items.every((_,i)=>found[i]);
  if(allDone) Voice.huntDone(p.name);

  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title={active.title} onBack={()=>setActive(null)}/>
      <View style={{padding:18}}>
        <Text style={{color:C.muted,fontSize:14,marginBottom:14}}>Find each item and tap "Found!" to mark it off.</Text>
        {active.items.map((item,i)=>(
          <Card key={i} style={{marginBottom:12,flexDirection:'row',alignItems:'center',gap:14,backgroundColor:found[i]?C.greenL:'#fff'}}>
            <View style={{width:32,height:32,borderRadius:16,backgroundColor:found[i]?C.green:C.skyL,alignItems:'center',justifyContent:'center'}}>
              <Text style={{color:found[i]?'#fff':C.skyD,fontWeight:'900'}}>{found[i]?'✓':i+1}</Text>
            </View>
            <Text style={{flex:1,fontWeight:'800',color:C.txt,fontSize:15,textDecorationLine:found[i]?'line-through':'none'}}>{item}</Text>
            {!found[i] && (
              <TouchableOpacity onPress={()=>{setFound(f=>({...f,[i]:true}));Voice.scanSuccess(item);}}
                style={{backgroundColor:C.sky,borderRadius:10,paddingHorizontal:12,paddingVertical:7}}>
                <Text style={{color:'#fff',fontWeight:'800',fontSize:12}}>📷 Found!</Text>
              </TouchableOpacity>
            )}
          </Card>
        ))}
        {allDone && (
          <Card style={{backgroundColor:C.greenL,alignItems:'center',marginTop:14}}>
            <Text style={{fontSize:54}}>🎉</Text>
            <Text style={{fontSize:20,fontWeight:'900',color:C.greenD,marginTop:8}}>Hunt Complete!</Text>
            <Text style={{color:C.muted,marginBottom:14}}>+50 XP earned!</Text>
            <Btn label="Claim Reward! 🏆" bg={C.greenD} onPress={()=>{
              addActivity({id:uid(),pid,type:'hunt',msg:`${p.name} completed ${active.title}! 🗺️`,ts:Date.now()});
              addNotif({id:uid(),pid,type:'achievement',msg:`🗺️ ${p.name} completed ${active.title} and earned +50 XP!`,ts:Date.now(),read:false});
              setProg(pr=>({...pr,[active.id]:active.items.length}));
              setActive(null);
            }}/>
          </Card>
        )}
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// STORY
// ══════════════════════════════════════════════════════════════
function StoryScreen({go, page, isChild, words, pid}) {
  const mine=words.filter(w=>w.pid===pid);
  const [text,setText]=useState('');
  const [loading,setLoading]=useState(false);

  async function gen() {
    setLoading(true);
    const wl=mine.slice(0,5).map(w=>w.word).join(', ');
    const hasKey=ANTHROPIC_KEY&&ANTHROPIC_KEY!=='';
    let s;
    if(hasKey){s=await buildStory(wl);}
    else{s=`Once upon a time, a brave explorer discovered a glowing ${mine[0]?.word||'treasure'} in an enchanted forest. A friendly elephant helped carry it and a loyal dog kept watch through the night. Together they crossed rivers of clouds to bring it home to their friends. From that day on, everyone knew that great adventures begin with a single step! 🌟`;}
    setText(s);setLoading(false);
    Voice.speak(`Your story is ready! ${s}`,{pitch:1.4,rate:0.88});
  }

  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="📖 Story Time" onBack={()=>go('ChildHome')}/>
      <View style={{padding:18}}>
        <Card style={{backgroundColor:C.purpleL,alignItems:'center',marginBottom:18}}>
          <Text style={{fontSize:56,marginBottom:8}}>📖</Text>
          <Text style={{fontSize:17,fontWeight:'800',color:C.txt,marginBottom:6}}>Make a Story with Your Words!</Text>
          <Text style={{color:C.muted,fontSize:13,marginBottom:14,textAlign:'center'}}>A magical adventure using the words you've learned.</Text>
          <Btn label={loading?'Writing… ✍️':'✨ Generate My Story!'} bg={mine.length===0?C.muted:C.purple}
            disabled={loading||mine.length===0} onPress={gen} style={{width:'100%'}}/>
          {mine.length===0&&<Text style={{color:C.red,fontSize:12,marginTop:8}}>Scan some objects first!</Text>}
        </Card>
        {loading&&<View style={{alignItems:'center',padding:30,gap:12}}><ActivityIndicator size="large" color={C.purple}/><Text style={{color:C.muted}}>Crafting your story…</Text></View>}
        {text!==''&&(
          <Card style={{backgroundColor:'#FEFCE8'}}>
            <Text style={{fontSize:11,color:'#A16207',fontWeight:'800',marginBottom:8}}>🌟 YOUR STORY</Text>
            <Text style={{color:C.txt,lineHeight:26,fontSize:15,marginBottom:14}}>{text}</Text>
            <View style={{flexDirection:'row',gap:10}}>
              <TouchableOpacity onPress={()=>Voice.speak(text,{pitch:1.4,rate:0.88})}
                style={{flex:1,backgroundColor:C.skyD,borderRadius:10,padding:10,alignItems:'center'}}>
                <Text style={{color:'#fff',fontWeight:'800',fontSize:12}}>🔊 Read Aloud</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={gen}
                style={{flex:1,backgroundColor:C.purple,borderRadius:10,padding:10,alignItems:'center'}}>
                <Text style={{color:'#fff',fontWeight:'800',fontSize:12}}>✨ New Story</Text>
              </TouchableOpacity>
            </View>
          </Card>
        )}
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// PARENT HOME
// ══════════════════════════════════════════════════════════════
function ParentHome({go, page, isChild, profiles, words, notifs, activity, controls}) {
  const unread=notifs.filter(n=>!n.read).length;
  return (
    <Shell page={page} go={go} isChild={isChild}>
      <View style={{backgroundColor:C.navy,padding:24,paddingTop:48,borderBottomLeftRadius:32,borderBottomRightRadius:32}}>
        <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'flex-start'}}>
          <View>
            <Text style={{color:'#fff',fontSize:22,fontWeight:'900'}}>Parent Dashboard 👨‍👩‍👧</Text>
            <Text style={{color:'#fff',opacity:0.8,fontSize:14,marginTop:4}}>Safety overview & controls</Text>
          </View>
          <TouchableOpacity onPress={()=>go('Notifications')}
            style={{backgroundColor:'rgba(255,255,255,.15)',borderRadius:14,padding:12}}>
            <Text style={{fontSize:24}}>🔔</Text>
            {unread>0&&(
              <View style={{position:'absolute',top:-4,right:-4,backgroundColor:C.red,borderRadius:10,
                width:18,height:18,alignItems:'center',justifyContent:'center'}}>
                <Text style={{color:'#fff',fontSize:10,fontWeight:'900'}}>{unread}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <View style={{padding:18}}>
        {unread>0&&(
          <Card onPress={()=>go('Notifications')} style={{backgroundColor:C.amberL,marginBottom:14}}>
            <View style={{flexDirection:'row',alignItems:'center',gap:12}}>
              <Text style={{fontSize:28}}>🔔</Text>
              <View style={{flex:1}}>
                <Text style={{fontWeight:'800',color:'#92400E',fontSize:14}}>{unread} new notification{unread>1?'s':''}</Text>
                <Text style={{color:'#B45309',fontSize:12}}>Tap to view all alerts</Text>
              </View>
              <Text style={{color:'#B45309',fontSize:20}}>›</Text>
            </View>
          </Card>
        )}

        <View style={{flexDirection:'row',gap:10,marginBottom:18}}>
          {[{i:'👶',v:profiles.length,l:'Kids'},{i:'📖',v:words.length,l:'Words'},{i:'🔥',v:Math.round(profiles.reduce((s,p)=>s+p.streak,0)/Math.max(profiles.length,1)),l:'Avg Streak'}].map(s=>(
            <Card key={s.l} style={{flex:1,alignItems:'center',padding:12}}>
              <Text style={{fontSize:22}}>{s.i}</Text>
              <Text style={{fontSize:20,fontWeight:'900',color:C.txt}}>{s.v}</Text>
              <Text style={{fontSize:10,color:C.muted}}>{s.l}</Text>
            </Card>
          ))}
        </View>

        <Text style={{fontSize:17,fontWeight:'900',color:C.txt,marginBottom:12}}>Children</Text>
        {profiles.map(p=>{
          const cfg=controls[p.id]||DEFAULT_CTRL;
          const pct=Math.min(100,cfg.screenTimeUsed/cfg.screenTimeLimit*100);
          const tc=pct>80?C.red:pct>60?C.amber:C.green;
          return (
            <Card key={p.id} style={{marginBottom:14}}>
              <View style={{flexDirection:'row',alignItems:'center',gap:12,marginBottom:10}}>
                <Avi av={p.av} size={44}/>
                <View style={{flex:1}}>
                  <View style={{flexDirection:'row',alignItems:'center',gap:8}}>
                    <Text style={{fontWeight:'800',color:C.txt,fontSize:16}}>{p.name}</Text>
                    {cfg.locked&&<View style={{backgroundColor:C.redL,borderRadius:8,paddingHorizontal:6,paddingVertical:2}}><Text style={{color:C.red,fontSize:10,fontWeight:'800'}}>🔒 LOCKED</Text></View>}
                  </View>
                  <Text style={{color:C.muted,fontSize:12}}>Age {p.age} · {words.filter(w=>w.pid===p.id).length} words</Text>
                </View>
                <Text style={{color:C.gold,fontWeight:'800',fontSize:13}}>🔥 {p.streak}d</Text>
              </View>
              <XPBar xp={p.xp} level={p.level}/>
              <View style={{marginTop:10}}>
                <View style={{flexDirection:'row',justifyContent:'space-between',marginBottom:3}}>
                  <Text style={{fontSize:11,color:C.muted}}>⏱️ Screen time today</Text>
                  <Text style={{fontSize:11,color:tc,fontWeight:'700'}}>{cfg.screenTimeUsed}/{cfg.screenTimeLimit} min</Text>
                </View>
                <View style={{height:6,backgroundColor:'#F1F5F9',borderRadius:4}}>
                  <View style={{width:`${pct}%`,height:'100%',backgroundColor:tc,borderRadius:4}}/>
                </View>
              </View>
            </Card>
          );
        })}

        <Text style={{fontSize:17,fontWeight:'900',color:C.txt,marginBottom:12}}>Quick Actions</Text>
        <View style={{flexDirection:'row',flexWrap:'wrap',gap:12,marginBottom:18}}>
          {[
            {i:'🔔',l:'Notifications',p:'Notifications',bg:C.amberL,ac:'#B45309'},
            {i:'🛡️',l:'Controls',     p:'Controls',     bg:C.redL,  ac:C.red},
            {i:'📋',l:'Activity Log', p:'ActivityLog',  bg:C.skyL,  ac:C.skyD},
            {i:'📈',l:'Progress',     p:'Progress',     bg:C.greenL,ac:C.greenD},
          ].map(a=>(
            <Card key={a.l} onPress={()=>go(a.p)} style={{width:(W-48)/2,backgroundColor:a.bg,alignItems:'center',padding:16}}>
              <Text style={{fontSize:34}}>{a.i}</Text>
              <Text style={{fontWeight:'800',color:a.ac,marginTop:6,fontSize:14}}>{a.l}</Text>
            </Card>
          ))}
        </View>

        <Text style={{fontSize:17,fontWeight:'900',color:C.txt,marginBottom:12}}>Recent Activity</Text>
        {activity.slice(0,4).map(a=>{
          const pr=profiles.find(x=>x.id===a.pid);
          return (
            <Card key={a.id} style={{marginBottom:10}}>
              <View style={{flexDirection:'row',gap:10,alignItems:'center'}}>
                <Text style={{fontSize:20}}>{a.type==='word'?'📖':a.type==='game'?'🎮':a.type==='scan'?'📷':'🗺️'}</Text>
                <View style={{flex:1}}>
                  <Text style={{fontSize:13,fontWeight:'700',color:C.txt}}>{a.msg}</Text>
                  <Text style={{fontSize:11,color:C.muted}}>{pr?.av} {pr?.name} · {timeAgo(a.ts)}</Text>
                </View>
                <Text style={{fontSize:14}}>✅</Text>
              </View>
            </Card>
          );
        })}
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// NOTIFICATIONS
// ══════════════════════════════════════════════════════════════
function NotificationsScreen({go, page, isChild, notifs, setNotifs, profiles}) {
  const unread=notifs.filter(n=>!n.read).length;
  const colors={achievement:C.amberL,game:C.purpleL,word:C.skyL,streak:C.coralL,safety:C.greenL};
  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="🔔 Notifications"/>
      <View style={{padding:18}}>
        {unread>0&&(
          <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
            <Text style={{color:C.skyD,fontWeight:'800'}}>{unread} unread</Text>
            <TouchableOpacity onPress={()=>setNotifs(n=>n.map(x=>({...x,read:true})))}
              style={{backgroundColor:C.muted,borderRadius:10,paddingHorizontal:12,paddingVertical:6}}>
              <Text style={{color:'#fff',fontWeight:'800',fontSize:12}}>Mark all read</Text>
            </TouchableOpacity>
          </View>
        )}
        {notifs.length===0&&<View style={{alignItems:'center',padding:60}}><Text style={{fontSize:48}}>🔕</Text><Text style={{color:C.muted,marginTop:12}}>No notifications yet</Text></View>}
        {notifs.map(n=>{
          const p=profiles.find(x=>x.id===n.pid);
          return (
            <View key={n.id} style={{marginBottom:12,opacity:n.read?0.7:1}}>
              <Card style={{backgroundColor:colors[n.type]||'#fff',borderWidth:n.read?0:1.5,borderColor:C.sky+'44'}}>
                <View style={{flexDirection:'row',gap:12,alignItems:'flex-start'}}>
                  <Text style={{fontSize:26,flexShrink:0}}>{n.type==='word'?'📖':n.type==='game'?'🎮':n.type==='streak'?'🔥':'🏆'}</Text>
                  <View style={{flex:1}}>
                    <View style={{flexDirection:'row',alignItems:'center',gap:8,marginBottom:3}}>
                      <Text style={{fontSize:14}}>{p?.av}</Text>
                      <Text style={{fontSize:12,color:C.muted,fontWeight:'700'}}>{p?.name} · {timeAgo(n.ts)}</Text>
                      {!n.read&&<View style={{backgroundColor:C.sky,borderRadius:8,paddingHorizontal:6,paddingVertical:1}}><Text style={{color:'#fff',fontSize:10,fontWeight:'800'}}>NEW</Text></View>}
                    </View>
                    <Text style={{fontSize:14,color:C.txt,fontWeight:n.read?'400':'700',lineHeight:20}}>{n.msg}</Text>
                  </View>
                  <TouchableOpacity onPress={()=>setNotifs(ns=>ns.filter(x=>x.id!==n.id))}>
                    <Text style={{fontSize:16,color:C.muted}}>✕</Text>
                  </TouchableOpacity>
                </View>
              </Card>
            </View>
          );
        })}
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// CONTROLS
// ══════════════════════════════════════════════════════════════
function ControlsScreen({go, page, isChild, profiles, controls, setControls, words}) {
  const [selPid,setSelPid]=useState(profiles[0]?.id||'p1');
  const p=profiles.find(x=>x.id===selPid)||profiles[0];
  const cfg=controls[selPid]||DEFAULT_CTRL;
  function upd(key,val){setControls(c=>({...c,[selPid]:{...(c[selPid]||DEFAULT_CTRL),[key]:val}}));}
  const pct=Math.min(100,cfg.screenTimeUsed/cfg.screenTimeLimit*100);
  const tc=pct>80?C.red:pct>60?C.amber:C.green;

  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="🛡️ Parental Controls"/>
      <View style={{padding:18}}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:18}}>
          {profiles.map(pr=>(
            <TouchableOpacity key={pr.id} onPress={()=>setSelPid(pr.id)}
              style={{flexDirection:'row',alignItems:'center',gap:8,
                backgroundColor:selPid===pr.id?C.skyD:'#fff',
                borderRadius:16,paddingHorizontal:16,paddingVertical:10,marginRight:10,
                shadowColor:'#000',shadowOpacity:0.08,shadowRadius:6,elevation:2}}>
              <Text style={{fontSize:22}}>{pr.av}</Text>
              <Text style={{color:selPid===pr.id?'#fff':C.txt,fontWeight:'800',fontSize:14}}>{pr.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <Card style={{marginBottom:14,backgroundColor:cfg.locked?C.redL:'#fff',borderWidth:2,borderColor:cfg.locked?C.red:C.border}}>
          <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
            <View style={{flexDirection:'row',alignItems:'center',gap:12}}>
              <Text style={{fontSize:28}}>{cfg.locked?'🔒':'🔓'}</Text>
              <View>
                <Text style={{fontWeight:'900',color:cfg.locked?C.red:C.txt,fontSize:15}}>{cfg.locked?'Account Locked':'Account Active'}</Text>
                <Text style={{color:C.muted,fontSize:12}}>{cfg.locked?`${p.name} cannot access app`:'Tap to lock immediately'}</Text>
              </View>
            </View>
            <Toggle on={cfg.locked} onToggle={()=>upd('locked',!cfg.locked)}/>
          </View>
        </Card>

        <Card style={{marginBottom:14}}>
          <View style={{flexDirection:'row',alignItems:'center',gap:10,marginBottom:12}}>
            <Text style={{fontSize:24}}>⏱️</Text>
            <View style={{flex:1}}>
              <Text style={{fontWeight:'800',color:C.txt,fontSize:15}}>Screen Time Limit</Text>
              <Text style={{color:C.muted,fontSize:12}}>Today: {cfg.screenTimeUsed}/{cfg.screenTimeLimit} min</Text>
            </View>
            <Text style={{fontWeight:'900',color:tc,fontSize:14}}>{Math.round(pct)}%</Text>
          </View>
          <View style={{height:10,backgroundColor:C.skyL,borderRadius:6,marginBottom:10}}>
            <View style={{width:`${pct}%`,height:'100%',backgroundColor:tc,borderRadius:6}}/>
          </View>
          <View style={{flexDirection:'row',alignItems:'center',gap:10}}>
            <Btn label="-5" bg={C.muted} style={{width:48,padding:10}} onPress={()=>upd('screenTimeLimit',Math.max(10,cfg.screenTimeLimit-5))}/>
            <Text style={{flex:1,textAlign:'center',fontWeight:'900',color:C.txt,fontSize:16}}>{cfg.screenTimeLimit} min</Text>
            <Btn label="+5" bg={C.skyD} style={{width:48,padding:10}} onPress={()=>upd('screenTimeLimit',Math.min(120,cfg.screenTimeLimit+5))}/>
          </View>
        </Card>

        <Card style={{marginBottom:14}}>
          <Text style={{fontWeight:'900',color:C.txt,fontSize:15,marginBottom:14}}>📱 Feature Access</Text>
          {[
            {key:'allowScanning',  label:'📷 Camera Scanning'},
            {key:'allowGames',     label:'🎮 Games'},
            {key:'allowStories',   label:'📖 Story Generator'},
            {key:'allowFlashcards',label:'🃏 Flashcards'},
          ].map(f=>(
            <View key={f.key} style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:14}}>
              <Text style={{color:C.txt,fontSize:14,fontWeight:'700'}}>{f.label}</Text>
              <Toggle on={cfg[f.key]!==false} onToggle={()=>upd(f.key,!cfg[f.key])}/>
            </View>
          ))}
        </Card>

        <Card style={{backgroundColor:C.navyL}}>
          <Text style={{fontWeight:'900',color:C.navy,fontSize:14,marginBottom:10}}>📚 {p.name}'s Words ({words.filter(w=>w.pid===selPid).length})</Text>
          {words.filter(w=>w.pid===selPid).length===0
            ?<Text style={{color:C.muted,fontSize:13}}>No words learned yet.</Text>
            :<View style={{flexDirection:'row',flexWrap:'wrap',gap:8}}>
              {words.filter(w=>w.pid===selPid).map(w=>(
                <View key={w.id} style={{backgroundColor:'#fff',borderRadius:10,paddingHorizontal:10,paddingVertical:5}}>
                  <Text style={{fontSize:12,fontWeight:'700',color:C.txt}}>{w.em} {w.word}</Text>
                </View>
              ))}
            </View>
          }
        </Card>
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// ACTIVITY LOG
// ══════════════════════════════════════════════════════════════
function ActivityLogScreen({go, page, isChild, activity, profiles}) {
  const [filter,setFilter]=useState('all');
  const types=['all','word','game','scan','hunt'];
  const icons={word:'📖',game:'🎮',scan:'📷',hunt:'🗺️',streak:'🔥'};
  const bgs={word:C.skyL,game:C.purpleL,scan:C.greenL,hunt:C.amberL};
  const filtered=filter==='all'?activity:activity.filter(a=>a.type===filter);
  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="📋 Activity Log"/>
      <View style={{padding:18}}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:14}}>
          {types.map(t=>(
            <TouchableOpacity key={t} onPress={()=>setFilter(t)}
              style={{backgroundColor:filter===t?C.skyD:'#fff',borderRadius:20,
                paddingHorizontal:14,paddingVertical:8,marginRight:8,borderWidth:1,borderColor:C.border}}>
              <Text style={{color:filter===t?'#fff':C.muted,fontWeight:'800',fontSize:12}}>
                {t==='all'?'All':t.charAt(0).toUpperCase()+t.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        {filtered.length===0&&<View style={{alignItems:'center',padding:40}}><Text style={{fontSize:48}}>📋</Text><Text style={{color:C.muted,marginTop:12}}>No activity yet</Text></View>}
        {filtered.map(a=>{
          const p=profiles.find(x=>x.id===a.pid);
          return (
            <Card key={a.id} style={{marginBottom:10,backgroundColor:bgs[a.type]||'#fff'}}>
              <View style={{flexDirection:'row',gap:12,alignItems:'center'}}>
                <Text style={{fontSize:24}}>{icons[a.type]||'📢'}</Text>
                <View style={{flex:1}}>
                  <Text style={{fontSize:14,fontWeight:'700',color:C.txt}}>{a.msg}</Text>
                  <Text style={{fontSize:11,color:C.muted,marginTop:2}}>{p?.av} {p?.name} · {timeAgo(a.ts)}</Text>
                </View>
                <Text style={{fontSize:16}}>✅</Text>
              </View>
            </Card>
          );
        })}
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// PROGRESS
// ══════════════════════════════════════════════════════════════
function ProgressScreen({go, page, isChild, profiles, words}) {
  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="📈 Progress" onBack={()=>go('ParentHome')}/>
      <View style={{padding:18}}>
        {profiles.map(p=>{
          const pw=words.filter(w=>w.pid===p.id).length;
          const bars=[3,6,4,8,5,7,pw%8+1];
          const mx=Math.max(...bars,1);
          return (
            <Card key={p.id} style={{marginBottom:20}}>
              <View style={{flexDirection:'row',alignItems:'center',gap:12,marginBottom:14}}>
                <Avi av={p.av} size={42}/><Text style={{fontSize:18,fontWeight:'900',color:C.txt}}>{p.name}</Text>
              </View>
              <View style={{flexDirection:'row',flexWrap:'wrap',gap:10,marginBottom:14}}>
                {[{l:'Words',v:pw,i:'📖'},{l:'Level',v:p.level,i:'⭐'},{l:'XP',v:p.xp,i:'✨'},{l:'Streak',v:p.streak,i:'🔥'}].map(s=>(
                  <View key={s.l} style={{backgroundColor:'#F8FAFF',borderRadius:12,padding:12,alignItems:'center',width:(W-72)/2}}>
                    <Text style={{fontSize:18}}>{s.i}</Text>
                    <Text style={{fontSize:18,fontWeight:'900',color:C.txt}}>{s.v}</Text>
                    <Text style={{fontSize:10,color:C.muted}}>{s.l}</Text>
                  </View>
                ))}
              </View>
              <Text style={{fontSize:11,color:C.muted,fontWeight:'800',marginBottom:8}}>WORDS — PAST 7 DAYS</Text>
              <View style={{flexDirection:'row',gap:4,alignItems:'flex-end',height:56}}>
                {bars.map((h,i)=>(
                  <View key={i} style={{flex:1,alignItems:'center',gap:3}}>
                    <View style={{width:'100%',height:Math.max(5,(h/mx)*50),backgroundColor:C.skyD,borderRadius:4}}/>
                    <Text style={{fontSize:9,color:C.muted}}>{'MTWTFSS'[i]}</Text>
                  </View>
                ))}
              </View>
            </Card>
          );
        })}
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// SETTINGS
// ══════════════════════════════════════════════════════════════
function SettingsScreen({go, page, isChild, setIsChild}) {
  return (
    <Shell page={page} go={go} isChild={isChild}>
      <TopBar title="⚙️ Settings"/>
      <View style={{padding:18}}>
        <Card style={{marginBottom:14,backgroundColor:C.purpleL}}>
          <Text style={{color:'#7E22CE',fontWeight:'900',fontSize:15,marginBottom:8}}>🤖 AI Features</Text>
          <Text style={{color:C.txt,fontSize:13,lineHeight:20,marginBottom:4}}>
            Real AI scanning uses your Anthropic API key set in App.js line 14.
          </Text>
          <Text style={{color:C.green,fontSize:12,fontWeight:'800'}}>
            {ANTHROPIC_KEY&&ANTHROPIC_KEY!==''?'✅ API Key is active!':'⚠️ No API key set — running in demo mode'}
          </Text>
        </Card>
        <Card style={{marginBottom:14,backgroundColor:C.amberL}}>
          <Text style={{color:'#B45309',fontWeight:'900',fontSize:14,marginBottom:6}}>📱 Publishing Costs</Text>
          <Text style={{color:C.txt,fontSize:13,lineHeight:20}}>Google Play: $25 one-time · Apple App Store: $99/year</Text>
        </Card>
        <Card style={{marginBottom:14,backgroundColor:C.skyL}}>
          <Text style={{color:C.skyD,fontWeight:'900',fontSize:14,marginBottom:6}}>👤 Account</Text>
          <Text style={{color:C.txt,fontSize:13}}>Expo Account: wordexplore1</Text>
        </Card>
        <Btn label="🚪 Switch User / Sign Out" bg={C.redL} fg={C.red}
          onPress={()=>{setIsChild(null);go('Welcome');}}/>
      </View>
    </Shell>
  );
}

// ══════════════════════════════════════════════════════════════
// ROOT APP
// ══════════════════════════════════════════════════════════════
export default function App() {
  const [page,     setPage]    = useState('Welcome');
  const [isChild,  setIsChild] = useState(null);
  const [profiles, setProfiles]= useState(INIT_PROFILES);
  const [words,    setWords]   = useState(INIT_WORDS);
  const [pid,      setPid]     = useState('p1');
  const [last,     setLast]    = useState(null);
  const [controls, setControls]= useState({p1:{...DEFAULT_CTRL},p2:{...DEFAULT_CTRL,screenTimeLimit:20,screenTimeUsed:8}});
  const [notifs,   setNotifs]  = useState(INIT_NOTIFS);
  const [activity, setActivity]= useState(INIT_ACTIVITY);

  function go(p) { setPage(p); }
  function addWord(w)    { setWords(ws=>[...ws,w]); }
  function addProfile(p) { setProfiles(ps=>[...ps,p]); setControls(c=>({...c,[p.id]:{...DEFAULT_CTRL}})); }
  function addNotif(n)   { setNotifs(ns=>[n,...ns]); }
  function addActivity(a){ setActivity(ac=>[a,...ac]); }

  const sp={go,page,isChild,setIsChild,profiles,words,pid,setPid,controls,setControls,notifs,setNotifs,activity,addActivity,addNotif};

  const screens={
    Welcome:       <Welcome       {...sp}/>,
    ChildHome:     <ChildHome     {...sp}/>,
    Scan:          <ScanScreen    {...sp} addWord={addWord} setLast={setLast}/>,
    Result:        <ResultScreen  {...sp} last={last}/>,
    Cards:         <FlashCards    {...sp}/>,
    Games:         <GamesHub      {...sp}/>,
    Awards:        <AwardsScreen  {...sp}/>,
    Hunt:          <HuntScreen    {...sp}/>,
    Story:         <StoryScreen   {...sp}/>,
    ParentHome:    <ParentHome    {...sp}/>,
    Notifications: <NotificationsScreen {...sp}/>,
    Controls:      <ControlsScreen     {...sp}/>,
    ActivityLog:   <ActivityLogScreen  {...sp}/>,
    Progress:      <ProgressScreen     {...sp}/>,
    Settings:      <SettingsScreen     {...sp}/>,
  };

  return (
    <View style={{flex:1,backgroundColor:C.bg}}>
      {screens[page]||screens.Welcome}
    </View>
  );
}
